﻿namespace SimpleCalculatorApi
{
    public static class Extensions
    {
        public static char ToChar(this ValueOperator value) => value switch
        {
            ValueOperator.add => '+',
            ValueOperator.subtract => '-',
            ValueOperator.multiply => '*',
            ValueOperator.divide => '/',
        };

        public static ValueOperator ToEnum(this char value) => value switch
        {
            '*' => ValueOperator.multiply,
            '/' => ValueOperator.divide,
            '+' => ValueOperator.add,
            '-' => ValueOperator.subtract,
            _ => throw new ArgumentException($"{value} is not supported atm.")
        };

        public static int ToInt(this string value) => Convert.ToInt32(value);
    }
}
