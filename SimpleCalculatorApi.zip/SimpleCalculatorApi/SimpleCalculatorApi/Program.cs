using Microsoft.AspNetCore.Mvc;
using SimpleCalculatorApi;

var builder = WebApplication.CreateBuilder(args);

builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddTransient<CalcHandler>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.MapGet("/calculate", async ([FromQuery()] string value, CalcHandler handler, HttpContext http) =>
{
    var toEvaluate = string.Concat(value.Where(c => !char.IsWhiteSpace(c)));
	var operators = new[] { '*', '/', '+', '-' };
	while (toEvaluate.IndexOfAny(operators) > -1)
	{
		var mapSolved = handler.BuildEquationMap(toEvaluate);
		foreach (var item in mapSolved)
		{
			toEvaluate = toEvaluate.Replace(item.Value.Item1, item.Value.Item2);
		}

		if (mapSolved.Count == 0)
		{
			break;
		}
	}

	await http.Response.WriteAsJsonAsync(new { Result = toEvaluate });
})
.WithName("EvaluationExpression");

app.Run();


internal record WeatherForecast(DateTime Date, int TemperatureC, string? Summary)
{
    public int TemperatureF => 32 + (int)(TemperatureC / 0.5556);
}
