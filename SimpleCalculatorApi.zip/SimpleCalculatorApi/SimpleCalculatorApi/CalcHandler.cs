﻿namespace SimpleCalculatorApi
{
	/// <summary>
	/// A simple calculation handler/explorer - with some caveats.
	/// - Does not handle brackets.
	/// - Does not handle negative values correctly.
	/// - Ran out of time playing/experimenting with net6 and c# 10 features.
	/// </summary>
    public class CalcHandler
    {
		public SortedDictionary<int, Tuple<string, string>> BuildEquationMap(in string value)
		{
			var map = new SortedDictionary<int, Tuple<ValueOperator, string>>();

			foreach (var c in value.ToCharArray().Where(x => !char.IsNumber(x)))
			{
				if (c.Equals('*') || c.Equals('/'))
				{
					var innerKey = value.IndexOf(c);
					var innerTupleKey = c.ToEnum();
                    ExtractSum(value, innerKey, out string innerExtract);
                    map.Add(innerKey, new(innerTupleKey, innerExtract));
					break;
				}

				if (value.Contains('*') || value.Contains('/'))
				{
					// skip processing other operators till we have exhausted above first.
					continue;
				}

				if (value.First() == c)
				{
					// skip leading '-' value.
					continue;
				}

				var key = value.IndexOf(c);
				var tupleKey = c.ToEnum();
                ExtractSum(value, key, out string extract);
                map.Add(key, new(tupleKey, extract));
				break;
			}

			var mapSolved = new SortedDictionary<int, Tuple<string, string>>();
			if (map.Any())
			{
				foreach (var item in map)
				{
					var splitOperator = item.Value.Item1.ToChar();
					var splitArray = item.Value.Item2.Split(splitOperator);
					var left = splitArray[0].ToInt();
					var right = splitArray[1].ToInt();
					var eq = new ValuePair(left, right, item.Value.Item1);
					var result = eq.Calculate().ToString();
					mapSolved.Add(item.Key, new(item.Value.Item2, result));
				}
			}

			return mapSolved;
		}

		private void ExtractSum(in string valueString, in int operatorPosition, out string slice)
		{
			var allIndices = GetSortedOperatorIndexes(valueString);
			var start = DetermineStartPosition(operatorPosition, allIndices, valueString);
			var end = DetermineEndPosition(operatorPosition, allIndices, valueString);

			slice = valueString[start..end];
		}

		private IList<int> GetSortedOperatorIndexes(in string value)
		{
			var indexes = new List<int>();
			foreach (var c in value.ToCharArray())
			{
				if (!char.IsNumber(c))
				{
					indexes.Add(value.IndexOf(c));
				}
			}
			indexes.Sort();
			return indexes;
		}

		private int DetermineStartPosition(int operatorPosition, in IList<int> allIndices, in string value)
		{
			if (allIndices.First() == operatorPosition)
			{
				return operatorPosition - operatorPosition;
			}

			var nextOperatorPosition = allIndices.IndexOf(operatorPosition) - 1;
			return allIndices[nextOperatorPosition] + 1;
		}

		private int DetermineEndPosition(int operatorPosition, in IList<int> allIndices, in string value)
		{
			if (allIndices.Last() == operatorPosition)
			{
				return value.Length;
			}

			var nextOperatorPosition = allIndices.IndexOf(operatorPosition) + 1;
			return allIndices[nextOperatorPosition];
		}
	}
}
