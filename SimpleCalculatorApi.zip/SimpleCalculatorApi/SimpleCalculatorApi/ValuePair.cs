﻿namespace SimpleCalculatorApi
{
    public enum ValueOperator
    {
        add,
        subtract,
        multiply,
        divide
    }

    public record struct ValuePair(int Left, int Right, ValueOperator operatorType)
    {
        public double Calculate() => operatorType switch
        {
            ValueOperator.add => Left + Right,
            ValueOperator.subtract => Left - Right,
            ValueOperator.multiply => Left * Right,
            ValueOperator.divide => Left / Right,
        };
    }
}
